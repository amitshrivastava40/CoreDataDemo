# Core-Data
Insert,Update,Delete &amp; Select Operation Using Core Data.
